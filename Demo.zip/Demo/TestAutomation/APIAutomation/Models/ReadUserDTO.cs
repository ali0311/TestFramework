﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIAutomation.Models
{
    public class ReadUserDTO
    {
        public DataGR Data { get; set; }
        public SupportGR Support { get; set; }
    }

    public partial class DataGR
    {
        public long Id { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Uri Avatar { get; set; }
    }

    public partial class SupportGR
    {
        public Uri Url { get; set; }
        public string Text { get; set; }
    }
}
