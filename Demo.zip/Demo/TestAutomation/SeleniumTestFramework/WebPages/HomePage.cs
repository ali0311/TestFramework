﻿using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumTestFramework.Initialize;
using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumTestFramework.WebPages
{
    public class HomePage : BasePage
    {
        public HomePage(IWebDriver webDriver, ILog logger) : base(webDriver, logger) { }

        private By HomePageHeader => By.XPath("//div[contains(@class,'app_logo') and contains(text(),'Swag Labs')]");
        private By BtnProductName(string prodNameWithHyphen) => By.XPath("//button[contains(@id,'" + prodNameWithHyphen + "') and contains(text(),'Add to cart')]");
        private By LnkCart => By.Id("shopping_cart_container");
        private By BtnCheckout => By.CssSelector("#checkout");
        private By TxtBoxFrstName => By.XPath("//input[@placeholder='First Name']");
        private By TxtBoxLstName => By.XPath("//input[@placeholder='Last Name']");
        private By TxtBoxCode => By.XPath("//input[@placeholder='Zip/Postal Code']");
        private By BtnContinue => By.Id("continue");
        private By BtnFinish => By.Id("finish");
        private By TxtCompleteOrder => By.XPath("//h2");
        private By IcnMenu => By.Id("react-burger-menu-btn");
        private By Logout => By.Id("logout_sidebar_link");



        public HomePage VerifyHomepage()
        {
            Assert.IsTrue(IsElementDisplayed(HomePageHeader));
            return this;
        }
        public HomePage AddProduct(string prodName)
        {
            Click(BtnProductName(prodName), "add to cart");
            return this;
        }
        public HomePage HandleAlert()
        {
            PerformDialogAction(DialogButton.ok);
            return this;
        }
        public HomePage CompletePurchase(string firstName, string lastName, string postalCode)
        {
            Click(LnkCart, "add to cart");
            Click(BtnCheckout, "add to cart");
            EnterText(TxtBoxFrstName, firstName, "First Name");
            EnterText(TxtBoxLstName, lastName, "Last Name");
            EnterText(TxtBoxCode, postalCode, "postal code");
            Click(BtnContinue, "continue");
            Click(BtnFinish, "finish");
            return this;
        }
        public HomePage ConfirmPurchase()
        {
            string msg = GetElementInnerText(TxtCompleteOrder, "get text");
            AssertAreEqual(msg, "Thank you for your order!", "Incorrect error message");
            return this;
        }
        public LoginPage LogoutFromApp()
        {
            Click(IcnMenu, "menu");
            Click(Logout, "logout");
            return new LoginPage(driver, log);
        }

    }
}

