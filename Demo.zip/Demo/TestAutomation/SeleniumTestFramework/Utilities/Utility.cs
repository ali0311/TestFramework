﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using log4net;
using SeleniumTestFramework.LogScript;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

namespace SeleniumTestFramework.Utilities
{
    public class Utility : LogService
    {
        public Utility(ILog logger) : base(logger) { }
        public void GetCPUUsageAndMemory()
        {
            //check current CPU Usage
            LogInfo("check current CPU Usage ");
            PerformanceCounter cpuCounter;
            PerformanceCounter ramCounter;

            cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            ramCounter = new PerformanceCounter("Memory", "Available MBytes");
            for (int i = 0; i < 4; i++)
            {
                var copUsage = cpuCounter.NextValue();
                Thread.Sleep(1000);
                LogInfo("Current CPU Utilization is: " + copUsage + "%");
                Console.WriteLine("Current CPU Utilization is: " + copUsage + "%");
            }
            var cpuMemory = ramCounter.NextValue();
            Console.WriteLine("Memory available: " + cpuMemory + "MB");
            LogInfo("Memory available: " + cpuMemory + "MB");
        }
    }
}

